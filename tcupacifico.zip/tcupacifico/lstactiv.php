<?php 
      require_once('codigos/conexion.inc');
 
      //Inicio la sesión
      session_start();

      //Utiliza los datos de sesion comprueba que el usuario este autenticado
      if ($_SESSION["autenticado"] != "SI") {
         header("Location:login.php");
         exit(); //fin del script
      }
	  
	  $AuxSql = "select ProductID, ProductName 
	             from products where CategoryID = ".$_GET['cod'];   

      $Regis = mysqli_query($conex,$AuxSql) or die(mysqli_error($conex));
      $NunFilas = mysqli_num_rows($Regis);	  
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <header class="row">
		<?php
			include_once("segmentos/menu.inc");
		?>
	</header>

 	 <script>
       function insproducto(){
			location.href="insproducto.php"; 
		}
    </script>
	<?php
		include_once("segmentos/encabe.inc");
	?>
</head>

            
	</header>

<main class="row">

        <button type="button" class="btn btn-sm btn-primary" 
                onClick="insproducto()">Agregar Actividad</button> 

		 <button type="button" class="btn btn-sm btn-primary" 
                onClick="inscateg()">Generar Reporte</button> 
    <br>
    <br>

<div id="contenedor">
    <?php
        echo " <label>       Horas Restantes:</label>";
        echo "<input type='text' value='$solucion' />";
    ?>
</div>
    

 <h3>Listas de actividades</h3> 
<?php
    	  
          
            if($NunFilas > 0){
              //  echo '<img src="codigos/imagen.php?cod='.$_GET['cod'].'" width="50%">';

                echo '<table class="table table-striped">';
                    echo "<thead>";
                        echo "<tr>";
                            echo "<td><strong>Numero de Actividad</strong></td> 
                                  <td><strong>Fecha</strong></td>
                                  <td><strong>Descripcion de actividad </strong></td>
                                  <td><strong>Hora inicio</strong></td>
                                  <td><strong>Hora final</strong></td>
                                   <td><strong>Horas  efectuadas</strong></td>
                                  <td colspan='2' align='center'><strong>Modificar</strong></td>";
                        echo "</tr>";
                    echo "</thead><tbody>";
                    while($Tupla = mysqli_fetch_assoc($Regis)){
                        echo "<tr>";
                            echo "<td>".$Tupla['ActividadID']."</td>";
                            echo "<td>".utf8_encode('FechaActiv')."</td>";
                            echo "<td>".utf8_encode($Tupla['Actividad'])."</td>";
                            echo "<td>".utf8_encode('Hinicio')."</td>";
                            echo "<td>".utf8_encode('Hfinal')."</td>";
                            echo "<td>".utf8_encode('Hefectuadas')."</td>";
						   	echo "<td align='center'>
							<a href='modifiLista.php?cod="
							.$Tupla['ActividadID']."'>Editar</a></td>";


                            echo "<td align='center'>
                            <a href='codigos/boractiv.php?codigo="
                            .$Tupla['ActividadID']."&cat=".$_GET['cod']."'>Borrar</a></td>";                  
                        echo "</tr>";
                    }                   
                echo "</tbody></table>";
            }else{
                echo "<h3>No hay datos disponibles</h3>";
            }

        ?>

     
<br>
<br>
        


	</main>


    

	<footer class="row pie">
		<?php
			include_once("segmentos/pie.inc");
		?>
	</footer>

	<!-- jQuery necesario para los efectos de bootstrap -->
    <script src="formatos/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script src="formatos/bootstrap/js/bootstrap.js"></script>
</body>
</html>
<?php
  if(isset($Regis)){
     mysqli_free_result($Regis);
  }
?>