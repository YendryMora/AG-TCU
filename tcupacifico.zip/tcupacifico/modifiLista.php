<?php 
   require_once('codigos/conexion.inc'); 
   
   //Inicio la sesión
       session_start();

      //Utiliza los datos de sesion comprueba que el usuario este autenticado
      if ($_SESSION["autenticado"] != "SI") {
         header("Location:login.php");
         exit(); //fin del scrip
      }



   if((isset($_POST["OC_Modi"])) && ($_POST["OC_Modi"] == "formita")) {
      $auxSql = sprintf("update products set ProductName = '%s', 
	                                           SupplierID = '%s',
                                               CategoryID = '%s',
                                               QuantityPerUnit = '%s',
                                               UnitPrice = '%s',
                                               UnitsInStock = '%s',
                                               UnitsOnOrder = '%s',
                                               ReorderLevel = '%s',
                                               Discontinued = '%s'
                                                                                              
						 where ProductID = %s",

              $_POST['txtNombre'],
              $_POST['txtprovedor'],
			  $_POST['txtcategoria'],
              $_POST['txtcantiuni'],
              $_POST['PrecioxUnd'],
              $_POST['Stock'],
              $_POST['txtuniOrden'],
              $_POST['txtnivelOrden'],
              $_POST['txtdescontinuidad'],
               $_POST['ocCodigo']);
             
         
      $Regis = mysqli_query($conex,$auxSql) or die(mysqli_error($conex));	
	  /*---------------------------*/
	  
	  //procesa el archivo enviado.
		$archivo = $_FILES["txtArchi"]["tmp_name"]; 
		$tamanio = $_FILES["txtArchi"]["size"];
		$tipo    = $_FILES["txtArchi"]["type"];
		$nombre  = $_FILES["txtArchi"]["name"];
		
		if ($archivo != "none" ){
			$archi = fopen($archivo, "rb");
			$contenido = fread($archi, $tamanio);
			$contenido = addslashes($contenido);
			fclose($archi); 

		/*	$AuxSql = "Update categories set Imagen='$contenido',
			           Mime='$tipo' Where CategoryID = " . $_POST['ocCodigo'];*/
							  
			$regis = mysqli_query($conex,$AuxSql) or die(mysqli_error($conex));
			
			echo "Se ha guardado el archivo en la base de datos.";
		}else
			print "No se puede subir el archivo ".$nombre."  al servidor"; 
	  
	  /*---------------------------*/  

      $aux = 'va por aca';
	  echo $aux;
      header("Location: lstproductos.php?cod=");
	  exit;
    };// fin del if	
	
	if(!isset($_POST["OC_Modi"])){
		$codigo = $_GET['cod'];
	}else{
		$codigo = $_POST['ocCodigo'];


	}
	$auxSql = sprintf("select ProductName ,SupplierID ,CategoryID ,QuantityPerUnit ,UnitPrice 
                      ,UnitsInStock ,UnitsOnOrder ,ReorderLevel,Discontinued from Products
	                   where CategoryID = %s", $codigo);
    
    $regis = mysqli_query($conex,$auxSql) or die(mysqli_error($conex));
	$tupla = mysqli_fetch_assoc($regis);  
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php
		include_once("segmentos/encabe.inc");
	?>
	<meta http-equiv="refresh" content="180;url=codigos/salir.php">
    <title>NorthWind (Categorías)</title>
</head>
<body class="container">
	<header class="row">
		<?php
			include_once("segmentos/menu.inc");
		?>
	</header>

	<main class="row">
		<div class="panel panel-primary">
            	<div class="panel-heading">
              		<h3 class="panel-title">Modificar Categoría</h3>
            	</div>
            	<div class="panel-body">
                    <form method="post" enctype="multipart/form-data"
                    name="formita" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                      <table class="table table-bordered">
                      	 <tr>
                           <td><strong>Código</strong></td>
                           <td><?php echo $codigo; ?></td>
                         </tr>
                         <tr>
                           <td><strong>Nombre</strong></td>
                           <td><input type="text" name="txtNombre" size="15" 
                           maxlength="15" 
                           value="<?php echo $tupla['ProductName']; ?>"></td>
                         </tr>
                         <tr>
                           <td><strong>Provedor</strong></td>
                           <td><input type="text" name="txtprovedor" size="50" maxlength="50" value="<?php echo $tupla['SupplierID']; ?>"></td>
                         </tr>
                   
                      <tr>
                           <td><strong>Categoria</strong></td>
                             <td><input type="text" name="txtcategoria" size="50" maxlength="50" value="<?php echo $tupla['CategoryID']; ?>"></td>
                         </tr>
                         

                            
                         <tr>
                              <td><strong>Cantidad por unidad</strong></td>
                              <td><input type="text" name="txtcantiuni" size="50" maxlength="50" value="<?php echo $tupla['QuantityPerUnit']; ?>"></td>
                         </tr>
    
                        
 
                          <tr>
                              <td><strong>PrecioxUnd</strong></td>
                              <td><input type="text" name="txtPrecio" size="50" maxlength="50" value="<?php echo $tupla['UnitPrice']; ?>"></td>
                            </tr>


                            <tr>
                              <td><strong>Stock</strong></td>
                              <td><input type="text" name="txtStock" size="50" maxlength="50" value="<?php echo $tupla['UnitsInStock']; ?>"></td>
                            </tr>
   

                            <tr>
                              <td><strong>Unid orden </strong></td>
                              <td><input type="text" name="txtuniOrden" size="50" maxlength="50" value="<?php echo $tupla['UnitsOnOrder']; ?>"></td>
                           </tr>
                              
                           
                            <tr>
                              <td><strong>Nivel orden</strong></td>
                              <td><input type="text" name="txtnivelOrden" size="50" maxlength="50" value="<?php echo $tupla['ReorderLevel']; ?>"></td>
                            </tr>

                            <tr>
                              <td><strong>Descontinuidad</strong></td>
                              <td><input type="text" name="txtdescontinuidad" size="50" maxlength="50" value="<?php echo $tupla['Discontinued']; ?>"></td>
                           </tr>
                                     
                                     
                        <tr>
                             <td colspan="2">
                             	<input type="submit" value="Aceptar">
                             </td>
                         </tr>
                      </table>
                      <input type="hidden" name="OC_Modi" value="formita">
                      <input type="hidden" name="ocCodigo" 
                             value="<?php echo $codigo; ?>">
                      
                    </form>                
               	</div>
            </div>
	</main>

	<footer class="row pie">
		<?php
			include_once("segmentos/pie.inc");
		?>
	</footer>

	<!-- jQuery necesario para los efectos de bootstrap -->
    <script src="formatos/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script src="formatos/bootstrap/js/bootstrap.js"></script>
</body>
</html>
<?php
  if(isset($regis)){
     mysqli_free_result($regis);
  }
?>
