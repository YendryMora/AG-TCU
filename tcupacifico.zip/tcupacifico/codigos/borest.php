<?php 
   require_once('conexion.inc'); 

   $auxSql = sprintf("delete from categories where CategoryID = %s", $_GET['cod']);
       
    $Regis = mysqli_query($conex, $auxSql ) or 
	         die(mysql_error());
    header("Location: ../categorias.php");  
?>