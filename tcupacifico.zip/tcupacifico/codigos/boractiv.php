
<?php 
 $idcate = $_GET['codigo'];
  $idcate = $_GET['cat'];



   require_once('conexion.inc'); 

   $auxSql = sprintf("delete from products where ProductID = %s", $_GET['codigo']);
       
    $Regis = mysqli_query($conex, $auxSql ) or 
             die(mysql_error());
     header("Location: ../lstproductos.php?cod=".$idcate); 
?>
-- header("Location: ../lstproductos.php?cod=.".$_GET['cat']);  