<?php
	require_once('conexion.inc'); 

	//Inicio la sesión
    session_start();

    //Utiliza los datos de sesion comprueba que el usuario este autenticado
    if ($_SESSION["autenticado"] != "SI") {
        header("Location: ../login.php");
        exit(); //fin del scrip
    }

    //Consulta los datos del usuario para la interfase
    $AuxSql = sprintf("Select Imagen, Mime from categories where CategoryID = %s", $_GET['cod']);
    $Regis = mysqli_query($conex, $AuxSql) or die(mysqli_error($conex));
	  
    $tupla = mysqli_fetch_assoc($Regis);
    header("Content-Type: ".$tupla['Mime']);    
    echo $tupla['Imagen'];
?>