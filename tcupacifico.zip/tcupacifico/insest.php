<?php 
   require_once('codigos/conexion.inc'); 
   
   //Inicio la sesión
       session_start();

      //Utiliza los datos de sesion comprueba que el usuario este autenticado
      if ($_SESSION["autenticado"] != "SI") {
         header("Location:login.php");
         exit(); //fin del scrip
      }

   if ((isset($_POST["OC_insertar"])) && ($_POST["OC_insertar"] == "formita")) {
      $auxSql = sprintf("insert into categories(CategoryName, Description) values('%s', '%s')",
              $_POST['txtNombre'],
              $_POST['txtDescrip']);
       
      $Regis = mysqli_query($conex,$auxSql) or die(mysqli_error($conex));
      header("Location: estudiantes.php");
   };// fin del if 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php
		include_once("segmentos/encabe.inc");
	?>	
	<meta http-equiv="refresh" content="180;url=codigos/salir.php">
    <title>(Estudiantes)</title>
    <script>
       function insest(){
			location.href="insest.php"; 
		}
    </script>	
</head>
<body class="container">
	<header class="row">
		<?php
			include_once("segmentos/menu.inc");
		?>
	</header>

	<main class="row">
		<div class="panel panel-primary">
            	<div class="panel-heading">
              		<h3 class="panel-title">Agregar Estudiante</h3>
            	</div>
            	<div class="panel-body">
                    <form method="post" name="formita" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                      <table class="table table-bordered">
                      	 <tr>
                           <td><strong>Cedula</strong></td>
                           <td><input type="text" name="txtCedula" size="15" maxlength="15"></td>
                         </tr>
                         <tr>
                           <td><strong>Nombre </strong></td>
                           <td><input type="text" name="txtNombre" size="50" maxlength="50"></td>
                         </tr>
                          <tr>
                           <td><strong>Primer Apellido </strong></td>
                           <td><input type="text" name="txtApe1" size="50" maxlength="50"></td>
                         </tr>
                          <tr>
                           <td><strong>Segundo Apellido</strong></td>
                           <td><input type="text" name="txtApe2" size="50" maxlength="50"></td>
                         </tr>
                          <tr>
                           <td><strong>Carrera</strong></td>
                           <td><input type="text" name="txtCarrera" size="50" maxlength="50"></td>
                         </tr>
                         <tr>
                           <td><strong>Trabaja</strong></td>
                           <td> 
                                <input type="checkbox" name="checkbox" id="checkbox1" /> 
                                <strong>Sí/No</strong>
                                 <input type="checkbox" name="checkbox" id="checkbox2" /> 
                           </td>
                         </tr>
                          <tr>
                           <td><strong>Telefono</strong></td>
                           <td><input type="text" name="txtNumTel" size="50" maxlength="50"></td>
                         </tr>
                          <tr>
                           <td><strong>Correo</strong></td>
                           <td><input type="text" name="txtCorreo" size="50" maxlength="50"></td>
                         </tr>
                           <tr>
                           <td><strong>Lugar de trabajo</strong></td>
                           <td><input type="text" name="txtTrabajo" size="50" maxlength="50"></td>
                         </tr>
                          <tr>
                           <td><strong>Numero de patrono o empresa</strong></td>
                           <td><input type="text" name="txtNumTrabajo" size="50" maxlength="50"></td>
                         </tr>
                         <tr>
                             <td colspan="2">
                             	<input type="submit" value="Aceptar">
                             </td>
                         </tr>
                      </table>
                      <input type="hidden" name="OC_insertar" value="formita">
                    </form>                
               	</div>
            </div>
	</main>

	<footer class="row pie">
		<?php
			include_once("segmentos/pie.inc");
		?>
	</footer>

	<!-- jQuery necesario para los efectos de bootstrap -->
    <script src="formatos/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script src="formatos/bootstrap/js/bootstrap.js"></script>
</body>
</html>