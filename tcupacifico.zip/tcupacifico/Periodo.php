<?php 
      require_once('codigos/conexion.inc');
 
       //Inicio la sesión
       session_start();

      //Utiliza los datos de sesion comprueba que el usuario este autenticado
      if ($_SESSION["autenticado"] != "SI") {
         header("Location:login.php");
         exit(); //fin del scrip
      }
	  
	  $auxSql = "select * from estudiantes";
      $regis = mysqli_query($conex, $auxSql) or die(mysqli_error());
      $nunFilas = mysqli_num_rows($regis);	  
 ?>     
<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" type="text/css" href="CSS.css"> 
<head>
	<?php
		include_once("segmentos/encabe.inc");
	?>
	
	<meta http-equiv="refresh" content="180;url=codigos/salir.php">
    <title>(Periodo)</title>
    <script>
       function insest(){
			location.href="insest.php"; 
		}
    </script>
    
</head>
<body class="container">
	<header class="row">
		<?php
			include_once("segmentos/menu.inc");
			
		?>
        

<style type="text/css"> 
/*div*/ { 
color: purple; 
background-color: #d8da3d } 
</style> 
<div>		
	
</header>
       
        
	</main>
    <div class="row">
		<div class="col-md-8">
		<label for="Sexo">Fecha de Inicio:</label>
		<input type="date" name="cumpleanios" step="1" min="2013-01-01" max="2013-12-31" value="<?php echo date("Y-m-d");?>">
		</div>
	</div>

    <br>

    <div class="row">
		<div class="col-md-8">
		<label for="Sexo">Fecha de Culminación:</label>
		<input type="date" name="cumpleanios" step="1" min="2013-01-01" max="2013-12-31" value="<?php echo date("Y-m-d");?>">
		</div>
	</div>
		
    <br>

	<div class="row">
		<div class="col-md-8">
		<label for="Sexo">Cuatrimestre</label>
		<div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
		<select name="Cuatrimestre" id="Cuatrimestre" class="form-control">
		<option value="">Seleccione&hellip;</option>
		<option value="1">Primer Cuatrimestre</option>
		<option value="2">Segundo Cuatrimiestre</option>
		<option value="2">Tercer Cuatrimestre</option>
		</select>
		</div>
	</div>
        
		</div>
        <br>
        <form method="POST" action="http://mysevidor/php/buscador.php3"> 
			        <input type="submit" value="Insertar Periodo" name="buscar" class="btn btn-sm btn-primary"> 
			    </form>

	<footer class="row pie">
		<?php
			include_once("segmentos/pie.inc");
		?>
	</footer>

	<!-- jQuery necesario para los efectos de bootstrap -->
    <script src="formatos/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script src="formatos/bootstrap/js/bootstrap.js"></script>
</body>
</html>
<?php
  if(isset($regis)){
     mysqli_free_result($regis);
  }
?>