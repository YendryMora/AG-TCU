<?php 
   require_once('codigos/conexion.inc'); 
   
   //Inicio la sesión
       session_start();

      //Utiliza los datos de sesion comprueba que el usuario este autenticado
      if ($_SESSION["autenticado"] != "SI") {
         header("Location:login.php");
         exit(); //fin del scrip
      }

   if ((isset($_POST["OC_insertar"])) && ($_POST["OC_insertar"] == "formita")) {

     echo     $_POST['txtFecha'];
    echo       $_POST['txtActividad'];
     echo         $_POST['txtHinicio'];
      echo        $_POST['txtHfinal'];
     echo         $_POST['txtHefectuadas'];
       
      $auxSql = sprintf("insert into products( Fecha, NomActividad, Hinicio, Hfinal, Hefectuadas) 
      values('%s', '%s','%s','%s','%s')",
              $_POST['txtFecha'],
              $_POST['txtActividad'],
              $_POST['txtHinicio'],
              $_POST['txtHfinal'],
              $_POST['txtHefectuadas']);
       
      $Regis = mysqli_query($conex,$auxSql) or die(mysqli_error($conex));
      header("Location: lstactiv.php");
   };// fin del if 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php
		include_once("segmentos/encabe.inc");
	?>	
	<meta http-equiv="refresh" content="180;url=codigos/salir.php">
    <title>NorthWind (Productos)</title>
    <script>
       function insproducto(){
			location.href="insactiv.php"; 
		}
    </script>	
</head>
<body class="container">
	<header class="row">
		<?php
			include_once("segmentos/menu.inc");
		?>
	</header>

	<main class="row">
		<div class="panel panel-primary">
            	<div class="panel-heading">
              		<h3 class="panel-title">Insertar Actividad</h3>
            	</div>
            	<div class="panel-body">
                    <form method="post" name="formita" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                      <table class="table table-bordered">
                    

                     
                      	 <tr>
                           <td><strong>Fecha</strong></td>
                           <td><input type="text" name="txtFecha" size="15" maxlength="15"></td>
                         </tr>
                     
                         <tr>
                           <td><strong>Descripciòn de actividad</strong></td>
                           <td><input type="text" name="txtActvidad" size="50" maxlength="50"></td>
                         </tr>
                         <tr>
                           <td><strong>Hora inicio</strong></td>
                           <td><input type="text" name="txtHinicio" size="50" maxlength="50"></td>
                         </tr>
                         <tr>
                           <td><strong>Hora Final</strong></td>
                           <td><input type="text" name="txtHfinal" size="50" maxlength="50"></td>
                         </tr>
                         <tr>
                           <td><strong>Horas efectuadas</strong></td>
                           <td><input type="text" name="txtHefectuadas" size="50" maxlength="50"></td>
                         </tr>
                         <tr>
                       
                         <tr>
                             <td colspan="2">
                             	<input type="submit" value="Aceptar">
                             </td>
                         </tr>
                      </table>
                      <input type="hidden" name="OC_insertar" value="formita">
                    </form>                
               	</div>
            </div>
	</main>

	<footer class="row pie">
		<?php
			include_once("segmentos/pie.inc");
		?>
	</footer>

	<!-- jQuery necesario para los efectos de bootstrap -->
    <script src="formatos/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script src="formatos/bootstrap/js/bootstrap.js"></script>
</body>
</html>