<?php 
      require_once('codigos/conexion.inc');
 
       //Inicio la sesión
       session_start();

      //Utiliza los datos de sesion comprueba que el usuario este autenticado
      if ($_SESSION["autenticado"] != "SI") {
         header("Location:login.php");
         exit(); //fin del scrip
      }
	  
	  $auxSql = "select * from estudiantes";
      $regis = mysqli_query($conex, $auxSql) or die(mysqli_error());
      $nunFilas = mysqli_num_rows($regis);	  
 ?>     
<!DOCTYPE html>
<html lang="en">
<head>
	<?php
		include_once("segmentos/encabe.inc");
	?>
	
	<meta http-equiv="refresh" content="180;url=codigos/salir.php">
    <title>(Estudiantes)</title>
    <script>
       function inscateg(){
			location.href="insest.php"; 
		}
    </script>
    
</head>
<body class="container">
	<header class="row">
		<?php
			include_once("segmentos/menu.inc");
			
		?>
	</header>


	<main class="row">
	 <button type="button" class="btn btn-sm btn-primary" 
                onClick="insest()">Agregar estudiante</button> 


	 <button type="button" class="btn btn-sm btn-primary" 
                onClick="Reportes()">Generar Reporte</button> 
<br>
<br>
		
			<form method="POST" action="http://mysevidor/php/buscador.php3"> 
			<strong>Numero de Cedula:</strong> <input type="text" name="T1" size="20"> 
			<input type="submit" value="Buscar" name="buscar" class="btn btn-sm btn-primary"> 
			</form> 


		<h3>Estudiantes</h3>
        <?php
			if($nunFilas > 0){
				echo '<table class="table table-striped">';
					echo "<thead>";
						echo "<tr>";
							echo "<td><strong>Cedula</strong></td> 
								  <td><strong>Nombre</strong></td> 
								  <td><strong>Carrera</strong></td>
								  <td><strong>Email</strong></td>
								  <td><strong>Telefono</strong></td>
								  <td colspan='2' align='center'><strong>Modificar</strong></td>";
						echo "</tr>";
					echo "</thead><tbody>";
					while($Tupla = mysqli_fetch_assoc($regis)){
						echo "<tr>";
							echo "<td><a href='lstproductos.php?cod=".$Tupla['Cedula']."'>".$Tupla['Cedula']."</a></td>";
							echo "<td>".$Tupla['NombreEst']."</td>";
							echo "<td>".utf8_encode($Tupla['CarreraEst'])."</td>";
							echo "<td>".$Tupla['Email']."</td>";
							echo "<td>".$Tupla['NumTel']."</td>";
							echo "<td align='center'>
							<a href='modest.php?cod="
							.$Tupla['Cedula']."'>Editar</a></td>";
							
							echo "<td align='center'>
							<a href='codigos/boractiv.php?cod="
							.$Tupla['Cedula']."'>Borrar</a></td>";
							
							
						echo "</tr>";
					}					
				echo "</tbody></table>";
			}else{
				echo "<h3>No hay datos disponibles</h3>";
			}
		?>    
      
        
	</main>

	<footer class="row pie">
		<?php
			include_once("segmentos/pie.inc");
		?>
	</footer>

	<!-- jQuery necesario para los efectos de bootstrap -->
    <script src="formatos/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script src="formatos/bootstrap/js/bootstrap.js"></script>
</body>
</html>
<?php
  if(isset($regis)){
     mysqli_free_result($regis);
  }
?>