<?php 
	require_once('codigos/conexion.inc'); 

   	$Accion_Formulario = $_SERVER['PHP_SELF'];

	if((isset($_POST['txtUsua'])) && (isset($_POST['txtContra']))) {
		$auxSql = sprintf("select * from usuarios where usuario = '%s' and contra = password('%s')", $_POST['txtUsua'],$_POST['txtContra']);
		print_r($_POST['txtContra'] );
		print_r($_POST['txtContra'] );
		$regis = mysqli_query($conex, $auxSql) or die(mysqli_error($conex));
       	$rowRegis = mysqli_fetch_assoc($regis);
		
       	$nunFilas = mysqli_num_rows($regis);

       	if($nunFilas > 0){
			//usuario y contraseña válidos, se define una sesion y datos de interes
          	session_start();
          	$_SESSION["autenticado"]= "SI";
          	$_SESSION["usuario"]=$rowRegis['usuario'];
		  
		  	//invoca la pagina
          	header("Location: categorias.php");
       	}else{          
			echo "<script> alert('Datos de autenticación incorrectos.'); </script>";
       	}
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php
		include_once("segmentos/encabe.inc");
	?>
</head>
<body class="container">
	<header class="row">
		<?php
			include_once("segmentos/menu.inc");
		?>
	</header>

	<main class="row">
		<div class="col-lg-4">&nbsp;</div>
		<div class="col-lg-4 linea_sep centrar">
        	<div class="panel panel-primary">
            	<div class="panel-heading">
              		<h3 class="panel-title">Autenticación de Usuarios</h3>
            	</div>
            	<div class="panel-body">
       				<form action="<?php echo $Accion_Formulario; ?>" method="post">
                       <table class="table table-bordered">
                       		<tbody>                                
                                <tr>
                                   <td align="right"><strong>Usuario:</strong></td>
                                   <td><input type="Text" name="txtUsua" size="20" maxlength="15" required></td>
                                </tr>
                                <tr>
                                   <td align="right"><strong>Contraseña:</strong></td>
                                   <td><input type="password" name="txtContra" size="20" maxlength="15" required> </td>

                                </tr>
                                <tr>
                                   <td colspan="2" align="center"> <input type="submit" class="btn btn-primary" value="Aceptar">   <a href="registro.php" class="btn btn-primary" role="button">Registrese Aqui</a> </td>
                                </tr>
                       		</tbody>         
                       </table>
                    </form>       
                </div>
            </div>
        </div>
	</main>

	<footer class="row pie">
		<?php
			include_once("segmentos/pie.inc");
		?>
	</footer>

	<!-- jQuery necesario para los efectos de bootstrap -->
    <script src="formatos/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script src="formatos/bootstrap/js/bootstrap.js"></script>
</body>
</html>
