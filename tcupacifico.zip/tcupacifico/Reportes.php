<?php 
      require_once('codigos/conexion.inc');
 
       //Inicio la sesión
       session_start();

      //Utiliza los datos de sesion comprueba que el usuario este autenticado
      if ($_SESSION["autenticado"] != "SI") {
         header("Location:login.php");
         exit(); //fin del scrip
      }
	  
	  $auxSql = "select * from categories";
      $regis = mysqli_query($conex, $auxSql) or die(mysqli_error());
      $nunFilas = mysqli_num_rows($regis);	  
 ?>     
<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" type="text/css" href="CSS.css"> 
<head>
	<?php
		include_once("segmentos/encabe.inc");
	?>
	
	<meta http-equiv="refresh" content="180;url=codigos/salir.php">
    <title>NorthWind (Categorías)</title>
    <script>
       function inscateg(){
			location.href="inscateg.php"; 
		}
    </script>
    
</head>
<body class="container">
	<header class="row">
		<?php
			include_once("segmentos/menu.inc");
			
		?>
</header>
       
        
	</main>
	     	
			<br>
            <strong>Año:</strong> <input type="text" name="T1" size="20"> 
            <br>

			<br>

      
		<div class="row">
            <div class="col-md-8">
             <label for="Sexo">Cuatrimestre</label>

                 <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <select name="Cuatrimestre" id="Cuatrimestre" class="form-control">
                            <option value="">Seleccione&hellip;</option>
                            <option value="1">Primer Cuatrimestre</option>
                            <option value="2">Segundo Cuatrimiestre</option>
                            <option value="2">Tercer Cuatrimestre</option>
                        </select>
               </div>
            </div>
		</div>
    
    <br>
        <div class="row">
            <div class="col-md-8">
             <label for="Sexo">Carreras</label>
                 <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <select name="Cuatrimestre" id="Cuatrimestre" class="form-control">
                            <option value="">Seleccione&hellip;</option>
                            <option value="1">AA	ADMINISTRACIÓN ADUANERA</option>
                            <option value="2">DG	DISEÑO GRÁFICO</option>
                            <option value="3">GEHG	GESTIÓN DE EMPRESAS DE HOSPEDAJE Y GASTRONÓMICAS</option>
                            <option value="4">COFI	CONTABILIDAD Y FINANZAS</option>
                            <option value="5">GEC	GESTIÓN ECOTURISTICA</option>
                            <option value="6">GAE	GESTIÓN Y ADMINISTRACIÓN DE EMPRESAS</option>
                            <option value="7">IEL	INGENIERÍA ELÉCTRICA</option>
                            <option value="8">IEA	INGENIERÍA ELECTRÓNICA</option>
                            <option value="9">IPRI	INGENIERÍA EN PRODUCCIÓN INDUSTRIAL</option>
                            <option value="10">ITI	INGENIERÍA EN TECNOLOGÍAS DE INFORMACIÓN</option>
                            <option value="10">ILE	INGLES COMO LENGUA EXTRANJERA</option>
                            <option value="10"></option>


                        </select>
               </div>
            </div>
		</div>
   
            
            <br>

        <div class="row">
            <div class="col-md-8">
             <label for="Sexo">Estado</label>
                 <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <select name="Cuatrimestre" id="Cuatrimestre" class="form-control">
                            <option value="">Seleccione&hellip;</option>
                            <option value="1">Aprobado</option>
                            <option value="2">Pendiente</option>
                            <option value="2">Reprobado</option>
                        </select>
               </div>
            </div>
		</div>

        <br>
        <form method="POST" action="http://mysevidor/php/buscador.php3"> 
			        <input type="submit" value="Generar Reporte" name="buscar" class="btn btn-sm btn-primary"> 
			    </form>
        


        

	<footer class="row pie">
		<?php
			include_once("segmentos/pie.inc");
		?>
	</footer>

	<!-- jQuery necesario para los efectos de bootstrap -->
    <script src="formatos/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script src="formatos/bootstrap/js/bootstrap.js"></script>
</body>
</html>
<?php
  if(isset($regis)){
     mysqli_free_result($regis);
  }
?>