
<?php

if( isset($_POST['email']) ) 
{
   $db_host="localhost";
$db_user="root";
$db_password="";
$db_name="agendayork";
$db_table_name="usuarios";

    //suprime advertencias
    error_reporting(0);

	//proceso para conectar con el servidor 
    if(!$conex = mysqli_connect($db_host, $db_user, $db_password, $db_name)){
        echo "<h3><font color='red'>Error: No se puede conectar al servidor de MySQL.</font></h3>" . "<hr>";
        echo "<strong>Número........:</strong> " . mysqli_connect_errno() . "<br>";
        echo "<strong>Descripción...:</strong> " . mysqli_connect_error() . "<br>";
        exit;      
          
    }    
$db_connection = mysqli_connect($db_host, $db_user, $db_password, $db_name);

$subs_name = utf8_decode($_POST['nombre']);
$subs_last = utf8_decode($_POST['apellidos']);
$subs_email = utf8_decode($_POST['email']);

//$resultado=mysql_query("SELECT * FROM ".$db_table_name." WHERE esmail = '".$subs_email."'", $db_connection);
	$resultado = "Select *  from usuarios where email = '".$subs_email."'";
  $regis = mysqli_query($db_connection , $resultado);
print_r($regis);
if (mysqli_num_rows($regis)>0)
{
echo"algoflota1";
header('Location: Fail.html');

} else {
  // Get data written in json format
	$data = file_get_contents("php://input");
           $url = 'http://localhost/clase7/final/accdatosMySql2/registro.php';
        
            $options = array('http' => array('header'  => "Content-Type:application/json",
                                             'header'  => "Accept:application/json",
                                             'method'  => 'POST',
                                             'content' => json_encode($datos)));
        

    // Convert json data into data array
	$valores = json_decode($data,TRUE);	
echo $valores;
//$decode = json_decode($valores, true);
echo $decode;



  //echo($valores);
$contra='123';
    // Prepare SQL insert instruction
    	// $auxSql = "call insusuario('".utf8_decode("elpa")."','".utf8_decode("apacje")."','"."a@Llalal.com"."','".$contra."')";
   //     $auxSql = "call insusuario('".utf8_decode("elpa")."','".utf8_decode("apacje")."','"."a@Llalal.com"."','".$contra."')";
	$auxSql = "call insusuario('".utf8_decode($valores['nombre'])."','".utf8_decode($valores['apellidos'])."','".$valores['email']."','".$contra."')";
				$regis = mysqli_query($conex, $auxSql);
	echo"algo no flota";
//	$insert_value = 'INSERT INTO `' . $db_name . '`.`'.$db_table_name.'` (`Nombre` , `Apellido` , `Email`) VALUES ("' . $subs_name . '", "' . $subs_last . '", "' . $subs_email . '")';

//mysql_select_db($db_name, $db_connection);
$retry_value = mysql_query($insert_value, $db_connection);

//if (!$retry_value) {
  // die('Error: ' . mysql_error());

	
header('Location: Success.html');
}

mysql_close($db_connection);
}
		
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php
		include_once("segmentos/encabe.inc");
	?>
</head>
<body class="container">
	<header class="row">
		<?php
			include_once("segmentos/menu.inc");
		?>
	</header>

	<main class="row">
	<head>
  <style>
label.derecha {
 
      margin-right: 36px;
    
}

label.derecha2 {
 
      margin-right: 25px;
    
}
</style>
<meta charset="utf-8">
<title>Formulario de Registro SCIII</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
</head>
 
<body>
<div class="group">
  <form action="registro.php" method="POST">
  <h2><em>Formulario de Registro</em></h2>  
     
      <label class="derecha2" for="nombre">Nombre <span><em>(requerido)</em></span></label>
      <input type="text" name="nombre" class="form-input" required/>   
      <br>
      <br>

      
      <label class="derecha2"  for="apellido">Apellido <span><em>(requerido)</em></span></label>
      <input type="text" name="apellido" class="form-input" required/>         
       <br>
       <br>

       <label   for="Contra">Contraseña <span><em>(requerido)</em></span></label>
        <input type="text" name="nombre" class="form-input" required/>   
        <br>
        <br>
      
      <label  class="derecha"  for="email">Email <span><em>(requerido)</em></span></label>
      <input type="email" name="email" class="form-input" />

         <div class="row">
            <div class="col-md-8">
            <br>
             <label for="Sexo">Estado</label>
             <br>
                 <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <select name="Rol" id="Rol" class="form-control">
                            <option value="">Seleccione&hellip;</option>
                            <option value="1">Administrador</option>
                            <option value="2">Secretario </option>
                            
                            
                        </select>
               </div>
            </div>
		</div>
  <br>

      <input class="form-btn" name="submit" type="submit" value="Registrarse" />
    </p>
  </form>
</div>
</body>
</html>
	</main>

	<footer class="row pie">
		<?php
			include_once("segmentos/pie.inc");
		?>
	</footer>

	<!-- jQuery necesario para los efectos de bootstrap -->
    <script src="formatos/bootstrap/js/jquery-1.11.3.min.js"></script>
    <script src="formatos/bootstrap/js/bootstrap.js"></script>
</body>
</html>
